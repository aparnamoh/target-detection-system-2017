#include <avr/io.h>
#include <util/delay.h>

//Simple Wait Function
void Wait()
{
	uint8_t i;
	for(i=0;i<30;i++)
	{
		_delay_loop_2(0);
		_delay_loop_2(0);
		_delay_loop_2(0);
	}

}

void main()
{
	//Configure TIMER1
	TCCR1A|=(1<<COM1A1)|(1<<COM1B1)|(1<<WGM11);        //NON Inverted PWM
	TCCR1B|=(1<<WGM13)|(1<<WGM12)|(1<<CS11)|(1<<CS10); //PRESCALER=64 MODE 14(FAST PWM)

	ICR1=4999;  //fPWM=50Hz (Period = 20ms Standard).

	DDRD|=(1<<PD4)|(1<<PD5);   //PWM Pins as Out

	while(1)
	{
		
		OCR1A=109;   //5 degree
		Wait();
		OCR1A=121;//10
		Wait();
		OCR1A=145;//20
		Wait();
		OCR1A=170;// 30
		Wait();
		OCR1A=194;//40
		Wait();
		OCR1A=219;//50
		Wait();
		OCR1A=243;//60
		Wait();
		OCR1A=267;//70
		Wait();
		OCR1A=292;//80
		Wait();
		OCR1A=316;  //90 degree
		Wait();
		OCR1A=340;// 100
		Wait();
		OCR1A=365;//110
		Wait();
		OCR1A=389;// 120
		Wait();
		OCR1A=413;// 130
		Wait();
		OCR1A=438;//140
		Wait();
		OCR1A=462;// 150
		Wait();
		OCR1A=486;// 160
		Wait();
		OCR1A=511;//170
		Wait();
		OCR1A=535;  //180 degree
		Wait();
		OCR1A=109; 
		break;
	}
}




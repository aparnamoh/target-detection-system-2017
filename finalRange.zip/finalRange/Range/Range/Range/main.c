

#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <stdio.h>
#include <util/delay.h>
#include "USART0.h"


FILE *fio_0 = &usart0_Stream;

volatile unsigned char MIP;
float ECHOHigh, ECHOLow, ECHOHighPipe, distance;
volatile unsigned int TimeOutCnt,Tick;
int y;

/***************************************************************************************
When the echo length is longer than the counter duration, we use an additional byte to
indicate how many times we reach the maximum value.
***************************************************************************************/
ISR (TIMER1_OVF_vect) {	// For long ECHO's
	if(ECHOHighPipe >= 5) {
		TIMSK1 = 0;	// No further interrupts.
		TCCR1B = 0; // Stop Clock
		MIP = 0xFF;	// End Measurement
	}
	
	ECHOHighPipe++;	// Add 1 to High byte.
}

/***************************************************************************************
Interrupt service routine called when the input capture pin state is changed
***************************************************************************************/
ISR (TIMER1_CAPT_vect) {	// Start and Stop ECHO measurement;
	if((TCCR1B & (1<<ICES1)) != 0) { // a rising edge has been detected
		TCCR1B |= (1<<CS11);	// Start counting with ck/8;
		TCCR1B &= ~(1<<ICES1);  // Configure Negative Edge Capture for end of echo pulse.
	}
	
	else {						// a falling edge has been detected
		ECHOLow = TCNT1;
		ECHOHigh = ECHOHighPipe;
		TIMSK1 = (1<<OCIE1B);	// Enables the Compare B interrupt for POST Trigger Delay: Approx 10mS
		TCNT1 = 0;
	}
}


/***************************************************************************************
Interrupt service routine called when the counter 1 has reached the compare value
***************************************************************************************/
ISR (TIMER1_COMPB_vect) {	// Compare B: Post ECHO delay 10mS
	MIP = 0;	// End Measurement
}

/***************************************************************************************
Interrupt service routine called when the counter 1 has reached the compare value
***************************************************************************************/
ISR (TIMER1_COMPA_vect) {	// Compare A : End of Trigger Pulse
	PORTB &= ~(1<<PB1);
	TIMSK1 = (1<<ICIE1)|(1<<TOIE1); // enables the T/C1 Overflow and Capture interrupt;
	TCCR1B = (1<<ICES1);			// Set Positive edge for capture but Don't count yet


}

/******************************************************************************
******************************************************************************/


void Trigger( void ) {		// Config Timer 1 for 10 to 15uS pulse.
	if(MIP == 0) {	// Don't allow re-trigger.
		MIP = 1;				// Set Measurement in progress FLAG
		DDRB |= (1<<PB1);		// PB1 as Output for Trigger pulse.
		DDRD &= ~(1<<PD6);		// PD6 as Input for Input Capture (ECHO).
		
		TCNT1 = 0;				// Clear last Echo times.
		ECHOHighPipe = 0;
		
		OCR1B = 10100;			// 10 mS Post echo Delay
		OCR1A = 12;				// 10 us Trigger length

		PORTB |= (1<<PB1);		// Start Pulse.

		TIFR1 = 0xFF;			//  Clear all timer interrupt flags
		TCCR1A = 0;   // Timer mode with Clear Output on Match
		TCCR1B = (1<<WGM12) | (1<<CS11);  // Counting with CKio/8 CTC Mode enabled
		TIMSK1 = (1<<OCIE1A);	// enables the T/C1 Overflow, Compare A, and Capture interrupt;
	}
	
}

void Wait() //simple wait function
{
	uint8_t i;
	for(i=0;i<30;i++)
	{
		_delay_loop_2(0);
		_delay_loop_2(0);
		_delay_loop_2(0);
	}
}
void Wait1() //simple wait function
{
	uint8_t i;
	for(i=0;i<15;i++)
	{
		_delay_loop_2(0);
		_delay_loop_2(0);
		_delay_loop_2(0);
	}
}

void speaker()
{
	DDRD = (1<<PD7);
	TCCR2B |= (1<<CS22)|(1<<CS21); //prescale by 256
	TCCR2A |= (1<<COM2A0)|(1<<WGM21);
	TIMSK2 = (1<OCIE2A);
	if (distance<50){
		ICR1 = 89; // 350 Hz
		OCR2A = 112;
		Wait1();
		OCR2A = 0;
	}
	else if (distance<75){
		ICR1 = 86; // 362.5 Hz
		OCR2A = 112;
		Wait1();
		OCR2A = 0;
	}
	else if (distance<100){
		ICR1 = 83; // 375 Hz
		OCR2A = 112;
		Wait1();
		OCR2A = 0;
	}
	else if (distance<125){
		ICR1 = 81; // 387.5 Hz
		OCR2A = 112;
		Wait1();
		OCR2A = 0;
	}
	else if (distance<150){
		ICR1 = 78; // 400 Hz
		OCR2A = 112;
		Wait1();
		OCR2A = 0;
	}
	else if (distance<175){
		ICR1 = 76; // 412.5 Hz
		OCR2A = 112;
		Wait1();
		OCR2A = 0;
	}
	else if (distance<200){
		ICR1 = 74; // 425 Hz
		OCR2A = 112;
		Wait1();
		OCR2A = 0;
	}
	else if (distance<225){
		ICR1 = 71; // 437.5
		OCR2A = 112;
		Wait1();
		OCR2A = 0;
	}
	else if (distance<250){
		ICR1 = 69; // 450 Hz
		OCR2A = 112;
		Wait1();
		OCR2A = 0;
	}
	else if (distance<275){
		ICR1 = 68; // 462.5 Hz
		OCR2A = 112;
		Wait1();
		OCR2A = 0;
	}
	else if (distance<300){
		ICR1 = 66; // 475 Hz
		OCR2A = 112;
		Wait1();
		OCR2A = 0;
	}
	else if (distance<325){
		ICR1 = 64; // 487.5 Hz
		OCR2A = 112;
		Wait1();
		OCR2A = 0;
	}
	else if (distance<355){
		ICR1 = 62; // 500 Hz
		OCR2A = 112;
		Wait1();
		OCR2A = 0;
	}
}

/******************************************************************************
******************************************************************************/
int main(void){
	
	uint8_t key;
	
	init_uart0(95);
	
	sei();
	
	fprintf_P(fio_0,PSTR("Hello\n\n\r")	);
	y = 0;
	Wait1();
	/*key = uart0_getc();
	
	while (1 == 1) {
		while(uart0_RxCount() == 0){};
		switch(key){
			default:*/
			while(1){
			Trigger();
			while(MIP==1){};
			distance = (ECHOLow*0.5/58.0);
			if (distance<205){
				fprintf_P(fio_0,PSTR("Object is located %f cm away at angle %d\n\n\r"),	distance, y);
				speaker();
				Wait1();
			}
			else if (distance>=205){
				Wait();
			}
			if (y<180) {
				y = y+10;
			}
			else if (y=180){
				break;
			}
			}
		}




